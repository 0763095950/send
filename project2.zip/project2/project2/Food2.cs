﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project2
{
    public partial class Food2 : UserControl
    {
        public Food2()
        {
            InitializeComponent();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            Order O = new Order();
            O.Show();
        }

        private void bunifuThinButton26_Click(object sender, EventArgs e)
        {
            Order O = new Order();
            O.Show();
        }

        private void bunifuThinButton29_Click(object sender, EventArgs e)
        {
            Order O = new Order();
            O.Show();
        }

        private void bunifuThinButton22_Click(object sender, EventArgs e)
        {
            Order O = new Order();
            O.Show();
        }

        private void bunifuThinButton25_Click(object sender, EventArgs e)
        {
            Order O = new Order();
            O.Show();
        }

        private void bunifuThinButton28_Click(object sender, EventArgs e)
        {
            Order O = new Order();
            O.Show();
        }

        private void bunifuThinButton23_Click(object sender, EventArgs e)
        {
            Order O = new Order();
            O.Show();
        }

        private void bunifuThinButton24_Click(object sender, EventArgs e)
        {
            Order O = new Order();
            O.Show();
        }

        private void bunifuThinButton27_Click(object sender, EventArgs e)
        {
            Order O = new Order();
            O.Show();
        }
    }
}
